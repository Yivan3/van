from django.db import models

# Create your models here.
from django.db import models
from datetime import datetime

# Create your models here.

class StudentParent(models.Model):
    student_name = models.CharField(max_length=30, verbose_name='学生姓名')
    student_id = models.CharField(max_length=30, verbose_name='学生学号')
    student_grade = models.CharField(max_length=30, verbose_name='学生年级')
    student_class = models.CharField(max_length=30, verbose_name='学生班级')
    phone_number = models.CharField(max_length=30, verbose_name='手机号码')
    password = models.CharField(max_length=30, verbose_name='密码')

    def __str__(self):
        return f"{self.student_name} ({self.student_id})"


class Teacher(models.Model):
    name = models.CharField(max_length=30, verbose_name='姓名')
    phone_number = models.CharField(max_length=30, verbose_name='电话号码')
    teaching_grade = models.CharField(max_length=30, verbose_name='执教年级')
    teaching_class = models.CharField(max_length=30, verbose_name='执教班级')
    subject = models.CharField(max_length=30, verbose_name='教学科目')
    teacher_id = models.CharField(max_length=30, verbose_name='教师工号')
    password = models.CharField(max_length=30, verbose_name='密码')

    def __str__(self):
        return f"{self.name} ({self.teaching_class})"


class Homework(models.Model):
    teacher_id = models.CharField(max_length=30, verbose_name='教师工号')
    content = models.CharField(max_length=500, verbose_name='作业')
    time = models.CharField(max_length=100, verbose_name='布置时间')

    def __str__(self):
        return f"Teacher ID: {self.teacher_id}, Content: {self.content[:50]}"



class ClassInfo(models.Model):
    grade = models.CharField(max_length=30, verbose_name='年级')
    classNumber = models.CharField(max_length=30, verbose_name='班级')
    teacher_id = models.CharField(max_length=30, verbose_name='老师工号')
    day = models.CharField(max_length=100, verbose_name='星期几')
    period = models.CharField(max_length=100, verbose_name='时间')

    def __str__(self):
        return f"Grade: {self.grade}, Class Number: {self.classNumber}, Teacher ID: {self.teacher_id}"

