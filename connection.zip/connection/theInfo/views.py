from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from .models import *
from django.shortcuts import redirect




@csrf_exempt
def login(request):
    theData = JSONParser().parse(request)
    print(type(theData))
    # 如果是1则是家长
    if theData['identify'] == '1':
        # 到家长表进行比较
        userName = theData.get('username', None)
        password = theData.get('password', None)
        number = StudentParent.objects.filter(student_id=userName, password=password).count()
        studentParent= StudentParent.objects.get(student_id=userName, password=password)

        # 如果用户存在
        if number != 0:
            data = {
                "answer": "true"
            }
            return JsonResponse(data)
        # 如果用户不存在
        elif number == 0:
            data = {
                "answer": "false"
            }
            return JsonResponse(data)
    # 如果是2则是一个老师
    elif theData['identify'] == '2':
        # 到教师表进行比较
        userName = theData.get('username', None)
        password = theData.get('password', None)
        number = Teacher.objects.filter(teacher_id=userName, password=password).count()
        # 如果教师存在
        if number != 0:
            data = {
                "answer": "true"
            }
            return JsonResponse(data)
        # 如果教师不存在
        elif number == 0:
            data = {
                "answer": "false"
            }
            return JsonResponse(data)


@csrf_exempt
def register(request):
    theData = JSONParser().parse(request)
    # 1是家长
    if theData['identify'] == '1':
        parent = StudentParent(student_name=theData['name'], student_id=theData['id'],
                               student_class=theData['class'], phone_number=theData['phone'],
                               password=theData['password'],
                               student_grade=theData['grade'])
        parent.save()
    # 二是老师
    elif theData['identify'] == '2':
        teacher = Teacher(phone_number=theData['phone'], teaching_class=theData['class'], subject=theData['subject'],
                          password=theData['password'], teacher_id=theData['id'], teaching_grade=theData['grade'])
        teacher.save()
    data = {
        'answer': 'true'
    }
    return JsonResponse(data)


# Web端的登录
@csrf_exempt
def Login(request):
    theWay = request.method
    if theWay == 'GET':
        return render(request, 'index.html')
    elif theWay == 'POST':
        uname = request.POST.get('username')
        password = request.POST.get('password')
        theNumber = Teacher.objects.filter(teacher_id=uname, password=password).count()
        # 没这人
        if theNumber == 0:
            return render(request, 'index.html')
        else:
            request.session['mydata'] = uname
            return redirect('menu')


@csrf_exempt
def menu(request):
    theWay = request.method
    my_data = request.session.get('mydata')
    if theWay == 'GET':
        return render(request, 'menu.html')
    elif theWay == 'POST':
        choosen = request.POST.get('button')
        if choosen == 'layout':
            request.session['mydata'] = my_data
            return redirect('layout')
        elif choosen == 'send':
            request.session['mydata'] = my_data
            return redirect('send')
        elif choosen == 'change':
            request.session['mydata'] = my_data
            return redirect('change')


@csrf_exempt
# 发布课程
def layout(request):
    theWay = request.method
    my_data = request.session.get('mydata')
    if theWay == 'GET':
        return render(request, 'sendclass.html')
    elif theWay == 'POST':
        classNumber = request.POST.get('classSelect')
        subject = request.POST.get('subject')
        day = request.POST.get('day')
        time = request.POST.get('period')
        print('******************')
        print(classNumber, subject, day, time)
        teacher1 = Teacher.objects.get(teacher_id=my_data)
        print(teacher1.name)
        classInfo = ClassInfo(grade=teacher1.teaching_grade, classNumber=teacher1.teaching_class,
                              teacher_id=my_data, day=day, period=time)
        classInfo.save()
        request.session['mydata'] = my_data
        return redirect('menu')


@csrf_exempt
# 这是布置任务
def send(request):
    theWay = request.method
    # 这是传过来的教师账号
    my_data = request.session.get('mydata')
    if theWay == 'GET':
        return render(request, 'afterclass.html')
    elif theWay == 'POST':
        # 作业的内容和布置的时间
        todayhomework = request.POST.get('homework', '')
        present = datetime.now().strftime("%Y-%m-%d")
        new_homework = Homework(teacher_id=my_data, content=todayhomework, time=present)
        new_homework.save()
        request.session['mydata'] = my_data
        return redirect('menu')


@csrf_exempt
# 修改信息
def change(request):
    theWay = request.method
    # 这是教师id的别称
    my_data = request.session.get('mydata')
    if theWay == 'GET':
        return render(request, 'change.html')
    elif theWay == 'POST':
        student_name = request.POST.get('student_name')
        student_id = request.POST.get('student_id')
        student_phone = request.POST.get('student_phone')
        student_class = request.POST.get('classSelect')
        student_password = request.POST.get('student_password')
        print(student_name, student_id, student_phone, student_class, student_password)
        print(type(student_name), type(student_id))
        teacher = Teacher.objects.get(teacher_id=my_data)
        print('****************')
        print(teacher, teacher.teacher_id, teacher.teaching_grade, type(teacher.teacher_id))
        if StudentParent.objects.filter(student_name=student_name,
                                        student_id=student_id,
                                        student_class=teacher.teaching_class,
                                        student_grade=teacher.teaching_grade).count() == 0:
            print('***************')
            print('失败')
            request.session['mydata'] = my_data
            return redirect('menu')
        elif StudentParent.objects.filter(student_name=student_name,
                                          student_id=student_id,
                                          student_class=teacher.teaching_class,
                                          student_grade=teacher.teaching_grade).count() != 0:
            Student = StudentParent.objects.get(student_name=student_name,
                                                student_id=student_id,
                                                student_class=teacher.teaching_class,
                                                student_grade=teacher.teaching_grade)
            Student.password = student_password
            Student.save()
            print('***************')
            print('成功')
            request.session['mydata'] = my_data
            return redirect('menu')
